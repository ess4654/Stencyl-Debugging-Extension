# Stencyl-Debugging-Extension
An extension for the Stencylworks game engine that adds better functionality for debugging
